import { useEffect, useRef } from "react";
// Firebase imports
import { db } from "./firebase";
import {
  collection,
  doc,
  getDocs,
  setDoc,
  writeBatch,
} from "firebase/firestore";

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    // ====== Firebase helper functions ======
    async function fbLoadCollection(collName: string): Promise<any[]> {
      try {
        const snap = await getDocs(collection(db, collName));
        const arr: any[] = [];
        snap.forEach((d) => arr.push(d.data()));
        return arr;
      } catch {
        return [];
      }
    }

    // Additional Firebase helpers available if needed:
    // fbSaveDoc(collName, docId, data), fbDeleteDoc(collName, docId), fbLoadDoc(collName, docId)

    async function fbSaveAll(collName: string, items: any[], idField: string = "id") {
      try {
        // Delete existing docs first
        const existing = await getDocs(collection(db, collName));
        const batch1 = writeBatch(db);
        existing.forEach((d) => batch1.delete(d.ref));
        await batch1.commit();
        // Save new docs
        for (const item of items) {
          const dId = item[idField] || item.id || Math.random().toString(36).substr(2, 9);
          await setDoc(doc(db, collName, dId), item);
        }
      } catch (e) {
        console.error("Firebase saveAll error:", e);
      }
    }

    async function fbSaveMealMenu(menuObj: any) {
      try {
        await setDoc(doc(db, "mealMenu", "current"), menuObj);
      } catch (e) {
        console.error("Firebase saveMealMenu error:", e);
      }
    }

    async function fbLoadMealMenu(): Promise<any> {
      try {
        const snap = await getDocs(collection(db, "mealMenu"));
        let result: any = {};
        snap.forEach((d) => {
          result = d.data();
        });
        return result;
      } catch {
        return {};
      }
    }

    // ====== Original app code (adapted for Firebase) ======
    const STORAGE_USERS = "schoolAppUsers";
    const STORAGE_CLASSES = "schoolAppClasses";
    const STORAGE_ROOMS = "schoolAppRooms";
    const STORAGE_SCHEDULES = "schoolAppSchedules";
    const STORAGE_ATTENDANCE = "schoolAppAttendance";
    const STORAGE_GRADES = "schoolAppGrades";
    const STORAGE_MEALMENU = "schoolAppMealMenu";

    // Firebase collection names
    const FB_USERS = "users";
    const FB_CLASSES = "classes";
    const FB_ROOMS = "rooms";
    const FB_SCHEDULES = "schedules";
    const FB_ATTENDANCE = "attendance";
    const FB_GRADES = "grades";

    // ---- UI Elements ----
    const root = containerRef.current!;

    const authSection = root.querySelector("#authSection") as HTMLElement;
    const loginTab = root.querySelector("#loginTab") as HTMLElement;
    const registerTab = root.querySelector("#registerTab") as HTMLElement;
    const loginPanel = root.querySelector("#loginPanel") as HTMLElement;
    const registerPanel = root.querySelector("#registerPanel") as HTMLElement;
    const authMessage = root.querySelector("#authMessage") as HTMLElement;
    const loginForm = root.querySelector("#loginForm") as HTMLFormElement;
    const registerForm = root.querySelector("#registerForm") as HTMLFormElement;

    const dashboard = root.querySelector("#dashboard") as HTMLElement;
    const userNameDisplay = root.querySelector("#userNameDisplay") as HTMLElement;
    const userRoleBadge = root.querySelector("#userRoleBadge") as HTMLElement;
    const logoutBtn = root.querySelector("#logoutBtn") as HTMLElement;
    const sideMenu = root.querySelector("#sideMenu") as HTMLElement;
    const mainContent = root.querySelector("#mainContent") as HTMLElement;

    const modalOverlay = root.querySelector("#modalOverlay") as HTMLElement;
    const modalTitle = root.querySelector("#modalTitle") as HTMLElement;
    const modalDesc = root.querySelector("#modalDesc") as HTMLElement;
    const modalCloseBtn = root.querySelector("#modalClose") as HTMLElement;

    let currentUser: any = null;

    // ---- localStorage fallback (original code) ----
    function loadData(key: string, defaultValue: any = []) {
      try {
        const data = localStorage.getItem(key);
        if (data) return JSON.parse(data);
        else return defaultValue;
      } catch {
        return defaultValue;
      }
    }

    function saveData(key: string, value: any) {
      localStorage.setItem(key, JSON.stringify(value));
    }

    // ---- Sync helpers: save to both localStorage AND Firebase ----
    function saveDataSync(key: string, value: any) {
      saveData(key, value);
      // Also save to Firebase
      switch (key) {
        case STORAGE_USERS:
          fbSaveAll(FB_USERS, value, "id");
          break;
        case STORAGE_CLASSES:
          fbSaveAll(FB_CLASSES, value, "id");
          break;
        case STORAGE_ROOMS:
          fbSaveAll(FB_ROOMS, value, "id");
          break;
        case STORAGE_SCHEDULES:
          fbSaveAll(FB_SCHEDULES, value, "id");
          break;
        case STORAGE_ATTENDANCE:
          fbSaveAll(FB_ATTENDANCE, value, "id");
          break;
        case STORAGE_GRADES:
          fbSaveAll(FB_GRADES, value, "id");
          break;
        case STORAGE_MEALMENU:
          fbSaveMealMenu(value);
          break;
      }
    }

    // Load from Firebase first, fallback to localStorage
    async function loadDataFromFirebase(key: string, defaultValue: any = []): Promise<any> {
      let fbData: any;
      switch (key) {
        case STORAGE_USERS:
          fbData = await fbLoadCollection(FB_USERS);
          break;
        case STORAGE_CLASSES:
          fbData = await fbLoadCollection(FB_CLASSES);
          break;
        case STORAGE_ROOMS:
          fbData = await fbLoadCollection(FB_ROOMS);
          break;
        case STORAGE_SCHEDULES:
          fbData = await fbLoadCollection(FB_SCHEDULES);
          break;
        case STORAGE_ATTENDANCE:
          fbData = await fbLoadCollection(FB_ATTENDANCE);
          break;
        case STORAGE_GRADES:
          fbData = await fbLoadCollection(FB_GRADES);
          break;
        case STORAGE_MEALMENU:
          fbData = await fbLoadMealMenu();
          break;
        default:
          fbData = null;
      }

      if (key === STORAGE_MEALMENU) {
        if (fbData && Object.keys(fbData).length > 0) {
          saveData(key, fbData);
          return fbData;
        }
      } else {
        if (fbData && Array.isArray(fbData) && fbData.length > 0) {
          saveData(key, fbData);
          return fbData;
        }
      }

      // Fallback to localStorage
      return loadData(key, defaultValue);
    }

    // ---- Demo Data ----
    async function initDemoData() {
      // Try loading from Firebase first
      let users = await loadDataFromFirebase(STORAGE_USERS);
      if (!users || users.length === 0) {
        users = [
          { id: "admin-1", name: "Ivan Admin", username: "admin", password: "adminpass", role: "admin", classes: [] },
          { id: "teacher-1", name: "Marko Učitelj", username: "marko", password: "markopass", role: "teacher", classes: ["1A"] },
          { id: "student-1", name: "Ana Učenik", username: "ana", password: "anapass", role: "student", class: "1A" },
        ];
        saveDataSync(STORAGE_USERS, users);
      } else {
        saveData(STORAGE_USERS, users);
      }

      let classes = await loadDataFromFirebase(STORAGE_CLASSES);
      if (!classes || classes.length === 0) {
        classes = [
          { id: "1A", name: "1A - Razred" },
          { id: "2B", name: "2B - Razred" },
        ];
        saveDataSync(STORAGE_CLASSES, classes);
      } else {
        saveData(STORAGE_CLASSES, classes);
      }

      let rooms = await loadDataFromFirebase(STORAGE_ROOMS);
      if (!rooms || rooms.length === 0) {
        rooms = [
          { id: "R1", name: "Učionica 1" },
          { id: "R2", name: "Učionica 2" },
          { id: "Lab", name: "Računarski laboratorij" },
        ];
        saveDataSync(STORAGE_ROOMS, rooms);
      } else {
        saveData(STORAGE_ROOMS, rooms);
      }

      let schedules = await loadDataFromFirebase(STORAGE_SCHEDULES);
      if (!schedules || schedules.length === 0) {
        schedules = [
          { id: "sch-1", teacher: "teacher-1", classId: "1A", roomId: "R1", day: "Ponedjeljak", time: "08:00 - 08:45", lessonName: "Matematika" },
          { id: "sch-2", teacher: "teacher-1", classId: "1A", roomId: "R1", day: "Srijeda", time: "09:00 - 09:45", lessonName: "Fizika" },
        ];
        saveDataSync(STORAGE_SCHEDULES, schedules);
      } else {
        saveData(STORAGE_SCHEDULES, schedules);
      }

      let mealMenu = await loadDataFromFirebase(STORAGE_MEALMENU, {});
      if (!mealMenu || Object.keys(mealMenu).length === 0) {
        mealMenu = {
          Monday: "Piletina s rižom, salata",
          Tuesday: "Špageti Bolognese, voćka",
          Wednesday: "Riblji file, pire krumpir",
          Thursday: "Pizza s povrćem",
          Friday: "Ćevapi s lepinjom i lukom",
        };
        saveDataSync(STORAGE_MEALMENU, mealMenu);
      } else {
        saveData(STORAGE_MEALMENU, mealMenu);
      }

      // Also init empty arrays for attendance and grades if not present
      let attendance = await loadDataFromFirebase(STORAGE_ATTENDANCE);
      if (attendance && attendance.length > 0) saveData(STORAGE_ATTENDANCE, attendance);
      let grades = await loadDataFromFirebase(STORAGE_GRADES);
      if (grades && grades.length > 0) saveData(STORAGE_GRADES, grades);
    }

    // ---- Tab switching ----
    function switchTab(selected: string) {
      if (selected === "login") {
        loginTab.classList.add("active");
        loginTab.setAttribute("aria-selected", "true");
        loginTab.tabIndex = 0;
        registerTab.classList.remove("active");
        registerTab.setAttribute("aria-selected", "false");
        registerTab.tabIndex = -1;
        loginPanel.hidden = false;
        registerPanel.hidden = true;
      } else {
        registerTab.classList.add("active");
        registerTab.setAttribute("aria-selected", "true");
        registerTab.tabIndex = 0;
        loginTab.classList.remove("active");
        loginTab.setAttribute("aria-selected", "false");
        loginTab.tabIndex = -1;
        loginPanel.hidden = true;
        registerPanel.hidden = false;
      }
      authMessage.textContent = "";
    }

    loginTab.addEventListener("click", () => switchTab("login"));
    registerTab.addEventListener("click", () => switchTab("register"));
    loginTab.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); switchTab("login"); }
    });
    registerTab.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); switchTab("register"); }
    });

    // ---- Utilities ----
    function createId(prefix: string = "") {
      return prefix + "-" + Math.random().toString(36).substr(2, 9);
    }

    // ---- Login ----
    loginForm.addEventListener("submit", (e: Event) => {
      e.preventDefault();
      const username = (loginForm.querySelector("#loginUsername") as HTMLInputElement).value.trim();
      const password = (loginForm.querySelector("#loginPassword") as HTMLInputElement).value;
      if (!username || !password) {
        authMessage.textContent = "Molimo unesite korisničko ime i lozinku.";
        return;
      }
      const users = loadData(STORAGE_USERS);
      const user = users.find((u: any) => u.username === username);
      if (!user || user.password !== password) {
        authMessage.textContent = "Pogrešno korisničko ime ili lozinka.";
        return;
      }
      currentUser = user;
      startDashboard();
    });

    // ---- Register ----
    registerForm.addEventListener("submit", (e: Event) => {
      e.preventDefault();
      const name = (registerForm.querySelector("#registerName") as HTMLInputElement).value.trim();
      const role = (registerForm.querySelector("#registerRole") as HTMLSelectElement).value;
      const username = (registerForm.querySelector("#registerUsername") as HTMLInputElement).value.trim();
      const password = (registerForm.querySelector("#registerPassword") as HTMLInputElement).value;
      if (!name || !role || !username || !password) {
        authMessage.textContent = "Molimo ispunite sva polja.";
        return;
      }
      let users = loadData(STORAGE_USERS);
      if (users.find((u: any) => u.username === username)) {
        authMessage.textContent = "Korisničko ime je već zauzeto.";
        return;
      }
      const newUser: any = { id: createId(role), name, username, password, role };
      if (role === "teacher") newUser.classes = [];
      if (role === "student") newUser.class = null;
      users.push(newUser);
      saveDataSync(STORAGE_USERS, users);
      authMessage.style.color = "lightgreen";
      authMessage.textContent = "Registracija uspješna! Sada se možete prijaviti.";
      registerForm.reset();
      switchTab("login");
      setTimeout(() => { authMessage.textContent = ""; authMessage.style.color = ""; }, 5000);
    });

    // ---- Dashboard ----
    function startDashboard() {
      authSection.style.display = "none";
      dashboard.style.display = "flex";
      userNameDisplay.textContent = currentUser.name;
      userRoleBadge.textContent = currentUser.role === "admin" ? "Admin" : currentUser.role === "teacher" ? "Učitelj" : "Učenik";
      renderSideMenu();
      autoSelectFirstMenu();
    }

    function logout() {
      currentUser = null;
      dashboard.style.display = "none";
      authSection.style.display = "";
      loginForm.reset();
      registerForm.reset();
      authMessage.textContent = "";
      switchTab("login");
    }

    logoutBtn.addEventListener("click", () => logout());

    // ---- Side Menu ----
    function renderSideMenu() {
      sideMenu.innerHTML = "";
      let buttons: { id: string; label: string; icon: string }[] = [];
      if (currentUser.role === "admin") {
        buttons = [
          { id: "manageClasses", label: "Upravljanje razredima", icon: "class" },
          { id: "manageUsers", label: "Upravljanje korisnicima", icon: "groups" },
          { id: "manageSchedule", label: "Rasporedi i učionice", icon: "schedule" },
          { id: "mealMenu", label: "Jelovnik", icon: "restaurant_menu" },
          { id: "reports", label: "Izvještaji", icon: "insert_chart" },
          { id: "settings", label: "Postavke", icon: "settings" },
        ];
      } else if (currentUser.role === "teacher") {
        buttons = [
          { id: "mySchedule", label: "Moj raspored", icon: "schedule" },
          { id: "myClasses", label: "Učenici i razredi", icon: "groups" },
          { id: "gradesAttendance", label: "Ocjene i izostanci", icon: "assignment_turned_in" },
          { id: "teacherTracking", label: "Gdje su učitelji", icon: "location_on" },
          { id: "mealMenu", label: "Jelovnik", icon: "restaurant_menu" },
          { id: "reports", label: "Izvještaji", icon: "insert_chart" },
          { id: "settings", label: "Postavke", icon: "settings" },
        ];
      } else if (currentUser.role === "student") {
        buttons = [
          { id: "mySchedule", label: "Moj raspored", icon: "schedule" },
          { id: "myGrades", label: "Moje ocjene", icon: "grade" },
          { id: "myAttendance", label: "Moji izostanci", icon: "notification_important" },
          { id: "mealMenu", label: "Jelovnik", icon: "restaurant_menu" },
          { id: "settings", label: "Postavke", icon: "settings" },
        ];
      }

      buttons.forEach((button) => {
        const btn = document.createElement("button");
        btn.id = button.id;
        btn.classList.add("sideButton");
        btn.setAttribute("aria-label", button.label);
        btn.setAttribute("role", "menuitem");
        btn.innerHTML = `<span class="material-icons" aria-hidden="true" style="vertical-align:middle;">${button.icon}</span> <span style="vertical-align:middle;">${button.label}</span>`;
        btn.addEventListener("click", () => {
          clearMenuActive();
          btn.classList.add("active");
          renderContent(button.id);
        });
        sideMenu.appendChild(btn);
      });
    }

    function clearMenuActive() {
      [...sideMenu.querySelectorAll("button")].forEach((btn) => btn.classList.remove("active"));
    }

    function autoSelectFirstMenu() {
      if (sideMenu.firstChild) {
        (sideMenu.firstChild as HTMLElement).classList.add("active");
        renderContent((sideMenu.firstChild as HTMLElement).id);
      }
    }

    // ---- Render Content ----
    function renderContent(sectionId: string) {
      mainContent.scrollTo({ top: 0, behavior: "smooth" });
      switch (sectionId) {
        case "manageClasses": renderManageClasses(); break;
        case "manageUsers": renderManageUsers(); break;
        case "manageSchedule": renderManageSchedule(); break;
        case "mealMenu": renderMealMenu(); break;
        case "reports": renderReports(); break;
        case "settings": renderSettings(); break;
        case "mySchedule": renderMySchedule(); break;
        case "myClasses": renderMyClasses(); break;
        case "gradesAttendance": renderGradesAttendance(); break;
        case "teacherTracking": renderTeacherTracking(); break;
        case "myGrades": renderMyGrades(); break;
        case "myAttendance": renderMyAttendance(); break;
        default:
          mainContent.innerHTML = "<h3>Odaberite opciju iz menija</h3>";
      }
    }

    // ---- ADMIN: Manage Classes ----
    function renderManageClasses() {
      let classes = loadData(STORAGE_CLASSES);
      mainContent.innerHTML = `
        <h3>Upravljanje razredima</h3>
        <div class="card">
          <form id="addClassForm" aria-label="Obrazac za dodavanje razreda">
            <label for="classIdInput">Šifra razreda (npr. 1A)</label>
            <input type="text" id="classIdInput" maxlength="3" required aria-required="true" />
            <label for="classNameInput">Naziv razreda</label>
            <input type="text" id="classNameInput" required aria-required="true"/>
            <button type="submit" class="primary" aria-label="Dodaj razred">Dodaj razred</button>
          </form>
        </div>
        <h4>Postojeći razredi</h4>
        <table aria-label="Lista razreda">
          <thead><tr><th>Šifra</th><th>Naziv</th><th>Akcija</th></tr></thead>
          <tbody id="classesTableBody"></tbody>
        </table>
      `;
      const tbody = mainContent.querySelector("#classesTableBody")!;
      classes.forEach((c: any) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td>${c.id}</td><td>${c.name}</td><td><button aria-label="Obriši razred ${c.id}" data-id="${c.id}" class="deleteClassBtn secondary">Izbriši</button></td>`;
        tbody.appendChild(tr);
      });
      const form = mainContent.querySelector("#addClassForm") as HTMLFormElement;
      form.addEventListener("submit", (e: Event) => {
        e.preventDefault();
        const idVal = (form.querySelector("#classIdInput") as HTMLInputElement).value.trim().toUpperCase();
        const nameVal = (form.querySelector("#classNameInput") as HTMLInputElement).value.trim();
        if (classes.find((c: any) => c.id === idVal)) { alert("Razred s ovom šifrom već postoji."); return; }
        if (idVal && nameVal) {
          classes.push({ id: idVal, name: nameVal });
          saveDataSync(STORAGE_CLASSES, classes);
          renderManageClasses();
        }
      });
      tbody.querySelectorAll(".deleteClassBtn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          if (confirm(`Jeste li sigurni da želite izbrisati razred ${id}?`)) {
            classes = classes.filter((c: any) => c.id !== id);
            saveDataSync(STORAGE_CLASSES, classes);
            renderManageClasses();
          }
        });
      });
    }

    // ---- ADMIN: Manage Users ----
    function renderManageUsers() {
      let users = loadData(STORAGE_USERS);
      let classes = loadData(STORAGE_CLASSES);
      mainContent.innerHTML = `
        <h3>Upravljanje korisnicima</h3>
        <div class="card scrollable" style="max-height:400px; overflow-y:auto;">
          <table aria-label="Lista korisnika">
          <thead><tr><th>Ime i prezime</th><th>Korisničko ime</th><th>Uloga</th><th>Razred</th><th>Akcija</th></tr></thead>
          <tbody id="usersTableBody"></tbody>
          </table>
        </div>
        <div class="card" aria-label="Dodaj novog korisnika">
          <form id="addUserForm">
            <label for="addUserName">Ime i prezime</label>
            <input type="text" id="addUserName" required />
            <label for="addUserUsername">Korisničko ime</label>
            <input type="text" id="addUserUsername" required />
            <label for="addUserPassword">Lozinka</label>
            <input type="password" id="addUserPassword" required />
            <label for="addUserRole">Uloga</label>
            <select id="addUserRole" required>
              <option value="">Odaberite ulogu</option>
              <option value="admin">Admin</option>
              <option value="teacher">Učitelj</option>
              <option value="student">Učenik</option>
            </select>
            <label for="addUserClass">Razred (za učenike/učitelje)</label>
            <select id="addUserClass" aria-label="Razred">
              <option value="">Nije primjenjivo</option>
              ${classes.map((c: any) => `<option value="${c.id}">${c.id} - ${c.name}</option>`).join("")}
            </select>
            <button type="submit" class="primary">Dodaj korisnika</button>
          </form>
        </div>
      `;
      const tbody = mainContent.querySelector("#usersTableBody")!;
      users.forEach((u: any) => {
        const className = u.role === "student" ? (u.class || "-") : (u.classes ? u.classes.join(", ") : "-");
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${u.name}</td><td>${u.username}</td><td>${u.role}</td><td>${className}</td>
          <td><button data-id="${u.id}" aria-label="Obriši korisnika ${u.name}" class="deleteUserBtn secondary">Izbriši</button></td>
        `;
        tbody.appendChild(tr);
      });
      const form = mainContent.querySelector("#addUserForm") as HTMLFormElement;
      const roleSelect = form.querySelector("#addUserRole") as HTMLSelectElement;
      const classSelect = form.querySelector("#addUserClass") as HTMLSelectElement;
      roleSelect.addEventListener("change", () => {
        if (roleSelect.value === "student" || roleSelect.value === "teacher") {
          classSelect.disabled = false;
        } else {
          classSelect.value = "";
          classSelect.disabled = true;
        }
      });
      roleSelect.dispatchEvent(new Event("change"));

      form.addEventListener("submit", (e: Event) => {
        e.preventDefault();
        const nameVal = (form.querySelector("#addUserName") as HTMLInputElement).value.trim();
        const usernameVal = (form.querySelector("#addUserUsername") as HTMLInputElement).value.trim();
        const passwordVal = (form.querySelector("#addUserPassword") as HTMLInputElement).value;
        const roleVal = roleSelect.value;
        const classVal = classSelect.value;
        if (users.find((u: any) => u.username === usernameVal)) { alert("Korisničko ime je zauzeto."); return; }
        if (!nameVal || !usernameVal || !passwordVal || !roleVal) { alert("Molimo popunite sva obavezna polja."); return; }
        const newUser: any = { id: createId(roleVal), name: nameVal, username: usernameVal, password: passwordVal, role: roleVal };
        if (roleVal === "student") newUser.class = classVal || null;
        if (roleVal === "teacher") newUser.classes = classVal ? [classVal] : [];
        users.push(newUser);
        saveDataSync(STORAGE_USERS, users);
        renderManageUsers();
      });
      tbody.querySelectorAll(".deleteUserBtn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          if (confirm("Jeste li sigurni da želite izbrisati ovog korisnika?")) {
            users = users.filter((u: any) => u.id !== id);
            saveDataSync(STORAGE_USERS, users);
            renderManageUsers();
          }
        });
      });
    }

    // ---- ADMIN: Manage Schedule ----
    function renderManageSchedule() {
      let schedules = loadData(STORAGE_SCHEDULES);
      let users = loadData(STORAGE_USERS);
      let classes = loadData(STORAGE_CLASSES);
      let rooms = loadData(STORAGE_ROOMS);

      mainContent.innerHTML = `
      <h3>Rasporedi i učionice</h3>
      <div class="card scrollable" style="max-height: 320px; overflow-y: auto;">
        <table aria-label="Lista rasporeda">
          <thead><tr><th>Dan</th><th>Vrijeme</th><th>Nastavnik</th><th>Razred</th><th>Učionica</th><th>Naziv lekcije</th><th>Akcija</th></tr></thead>
          <tbody id="scheduleTableBody"></tbody>
        </table>
      </div>
      <div class="card" aria-label="Dodaj raspored">
        <form id="addScheduleForm">
          <label for="scheduleDay">Dan u tjednu</label>
          <select id="scheduleDay" required>
            <option value="">Odaberite dan</option>
            <option value="Ponedjeljak">Ponedjeljak</option>
            <option value="Utorak">Utorak</option>
            <option value="Srijeda">Srijeda</option>
            <option value="Četvrtak">Četvrtak</option>
            <option value="Petak">Petak</option>
          </select>
          <label for="scheduleTime">Vrijeme</label>
          <input type="text" id="scheduleTime" placeholder="npr. 08:00 - 08:45" required />
          <label for="scheduleTeacher">Učitelj</label>
          <select id="scheduleTeacher" required>
            <option value="">Odaberite učitelja</option>
            ${users.filter((u: any) => u.role === "teacher").map((u: any) => `<option value="${u.id}">${u.name}</option>`).join("")}
          </select>
          <label for="scheduleClass">Razred</label>
          <select id="scheduleClass" required>
            <option value="">Odaberite razred</option>
            ${classes.map((c: any) => `<option value="${c.id}">${c.id} - ${c.name}</option>`).join("")}
          </select>
          <label for="scheduleRoom">Učionica</label>
          <select id="scheduleRoom" required>
            <option value="">Odaberite učionicu</option>
            ${rooms.map((r: any) => `<option value="${r.id}">${r.name}</option>`).join("")}
          </select>
          <label for="scheduleLesson">Naziv lekcije</label>
          <input type="text" id="scheduleLesson" placeholder="npr. Matematika" required/>
          <button type="submit" class="primary">Dodaj termin</button>
        </form>
      </div>
      `;

      const tbody = mainContent.querySelector("#scheduleTableBody")!;
      tbody.innerHTML = "";
      schedules.forEach((sch: any) => {
        const teacher = users.find((u: any) => u.id === sch.teacher)?.name || "-";
        const className = classes.find((c: any) => c.id === sch.classId)?.id || "-";
        const roomName = rooms.find((r: any) => r.id === sch.roomId)?.name || "-";
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${sch.day}</td><td>${sch.time}</td><td>${teacher}</td><td>${className}</td><td>${roomName}</td><td>${sch.lessonName}</td>
          <td><button data-id="${sch.id}" aria-label="Izbriši termin" class="deleteScheduleBtn secondary"><span class="material-icons" aria-hidden="true" style="vertical-align:middle;">delete</span></button></td>
        `;
        tbody.appendChild(tr);
      });

      const form = mainContent.querySelector("#addScheduleForm") as HTMLFormElement;
      form.addEventListener("submit", (e: Event) => {
        e.preventDefault();
        const day = (form.querySelector("#scheduleDay") as HTMLSelectElement).value;
        const time = (form.querySelector("#scheduleTime") as HTMLInputElement).value.trim();
        const teacherId = (form.querySelector("#scheduleTeacher") as HTMLSelectElement).value;
        const classId = (form.querySelector("#scheduleClass") as HTMLSelectElement).value;
        const roomId = (form.querySelector("#scheduleRoom") as HTMLSelectElement).value;
        const lessonName = (form.querySelector("#scheduleLesson") as HTMLInputElement).value.trim();
        if (!day || !time || !teacherId || !classId || !roomId || !lessonName) { alert("Molimo popunite sva polja."); return; }
        const conflict = schedules.find((s: any) => s.day === day && s.time === time && (s.roomId === roomId || s.teacher === teacherId));
        if (conflict) { alert("Postoji sukob termina za zadane vrijeme, učitelja ili učionicu."); return; }
        schedules.push({ id: createId("sch"), day, time, teacher: teacherId, classId, roomId, lessonName });
        saveDataSync(STORAGE_SCHEDULES, schedules);
        renderManageSchedule();
      });

      tbody.querySelectorAll(".deleteScheduleBtn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          if (confirm("Jeste li sigurni da želite obrisati taj termin?")) {
            schedules = schedules.filter((s: any) => s.id !== id);
            saveDataSync(STORAGE_SCHEDULES, schedules);
            renderManageSchedule();
          }
        });
      });
    }

    // ---- Meal Menu ----
    function renderMealMenu() {
      const mealMenu = loadData(STORAGE_MEALMENU, {});
      mainContent.innerHTML = `
        <h3>Jelovnik škole</h3>
        <table aria-label="Jelovnik tjedna">
          <thead><tr><th>Dan</th><th>Jelovnik</th></tr></thead>
          <tbody>
            ${Object.entries(mealMenu).map(([day, menu]) => `<tr><td>${day}</td><td>${menu}</td></tr>`).join("")}
          </tbody>
        </table>`;
    }

    // ---- Reports ----
    function renderReports() {
      mainContent.innerHTML = '<h3>Generiranje izvještaja (AI simulacija)</h3><p>Izvještaji održavaju rad, temelje se na ocjenama, izostancima i rasporedu.</p>';
      const grades = loadData(STORAGE_GRADES);
      const attendance = loadData(STORAGE_ATTENDANCE);
      const users = loadData(STORAGE_USERS);
      let reportUsers: any[];
      if (currentUser.role === "admin" || currentUser.role === "teacher") {
        if (currentUser.role === "teacher") {
          reportUsers = users.filter((u: any) => u.role === "student" && u.class && currentUser.classes.includes(u.class));
        } else {
          reportUsers = users.filter((u: any) => u.role === "student");
        }
      } else {
        reportUsers = [currentUser];
      }
      if (reportUsers.length === 0) { mainContent.innerHTML += "<p>Nema učenika koje možete pregledati.</p>"; return; }
      const ul = document.createElement("ul");
      ul.style.listStyle = "none";
      ul.style.padding = "0";
      reportUsers.forEach((student: any) => {
        const li = document.createElement("li");
        li.style.marginBottom = "18px";
        const studentGrades = grades.filter((g: any) => g.studentId === student.id);
        let avgGrade = "N/A";
        if (studentGrades.length > 0) {
          const sum = studentGrades.reduce((acc: number, g: any) => acc + g.grade, 0);
          avgGrade = (sum / studentGrades.length).toFixed(2);
        }
        const absenceCount = attendance.filter((a: any) => a.studentId === student.id && a.status === "absent").length;
        li.innerHTML = `<strong>${student.name}</strong> - Prosječna ocjena: ${avgGrade} - Izostanci: ${absenceCount}<br/>${generateComment(avgGrade, absenceCount)}`;
        ul.appendChild(li);
      });
      mainContent.appendChild(ul);

      function generateComment(avgGradeStr: string, absences: number) {
        let comment = "";
        const avg = parseFloat(avgGradeStr);
        if (isNaN(avg)) {
          comment = "<em>Nema dovoljno podataka za izvještaj.</em>";
        } else {
          if (avg >= 4.5) comment += "Izvrsni rezultati! Održavajte dobar rad. ";
          else if (avg >= 3.5) comment += "Dobar napredak, ali može bolje. ";
          else comment += "Potrebno je više truda i pažnje. ";
          if (absences > 5) comment += "Pobrinite se za redovniju prisutnost na nastavi.";
          else if (absences > 0) comment += "Pazite da nema previše izostanaka.";
          else comment += "Redovito pohađanje nastave.";
        }
        return `<em>${comment}</em>`;
      }
    }

    // ---- Settings ----
    function renderSettings() {
      mainContent.innerHTML = `
        <h3>Postavke korisnika</h3>
        <form id="settingsForm">
          <label for="toggleTheme">Tamni način</label>
          <input type="checkbox" id="toggleTheme" aria-checked="false"/>
          <br/>
          <label for="emailUser">Email adresa (simulirano)</label>
          <input type="email" id="emailUser" placeholder="vašemail@primjer.com" />
          <button type="submit" class="primary">Spremi postavke</button>
        </form>
      `;
      const themeToggle = mainContent.querySelector("#toggleTheme") as HTMLInputElement;
      const themePref = localStorage.getItem("schoolAppTheme") || "light";
      themeToggle.checked = themePref === "dark";
      function updateTheme() {
        if (themeToggle.checked) {
          document.body.style.background = "linear-gradient(135deg, #1e293b, #0f172a)";
          localStorage.setItem("schoolAppTheme", "dark");
          themeToggle.setAttribute("aria-checked", "true");
        } else {
          document.body.style.background = "linear-gradient(135deg, #4a5568, #1e293b)";
          localStorage.setItem("schoolAppTheme", "light");
          themeToggle.setAttribute("aria-checked", "false");
        }
      }
      updateTheme();
      themeToggle.addEventListener("change", updateTheme);
      const form = mainContent.querySelector("#settingsForm") as HTMLFormElement;
      (form.querySelector("#emailUser") as HTMLInputElement).value = currentUser.email || "";
      form.addEventListener("submit", (e: Event) => {
        e.preventDefault();
        currentUser.email = (form.querySelector("#emailUser") as HTMLInputElement).value.trim();
        let users = loadData(STORAGE_USERS);
        const idx = users.findIndex((u: any) => u.id === currentUser.id);
        if (idx > -1) {
          users[idx] = currentUser;
          saveDataSync(STORAGE_USERS, users);
          alert("Postavke su spremljene.");
        }
      });
    }

    // ---- TEACHER: My Schedule ----
    function renderMySchedule() {
      const schedules = loadData(STORAGE_SCHEDULES);
      const users = loadData(STORAGE_USERS);
      const classes = loadData(STORAGE_CLASSES);
      const rooms = loadData(STORAGE_ROOMS);
      let filtered: any[] = [];
      if (currentUser.role === "teacher") filtered = schedules.filter((s: any) => s.teacher === currentUser.id);
      else if (currentUser.role === "student") { if (currentUser.class) filtered = schedules.filter((s: any) => s.classId === currentUser.class); }
      else if (currentUser.role === "admin") filtered = schedules;

      mainContent.innerHTML = `
        <h3>Moj raspored</h3>
        <table aria-label="Raspored">
          <thead><tr><th>Dan</th><th>Vrijeme</th><th>Učitelj</th><th>Razred</th><th>Učionica</th><th>Čas lekcija</th><th>Akcija</th></tr></thead>
          <tbody id="scheduleBody"></tbody>
        </table>
      `;
      const tbody = mainContent.querySelector("#scheduleBody")!;
      if (filtered.length === 0) { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;">Nema termina</td></tr>'; return; }
      filtered.forEach((s: any) => {
        const teacherName = users.find((u: any) => u.id === s.teacher)?.name || "-";
        const className = classes.find((c: any) => c.id === s.classId)?.id || "-";
        const roomName = rooms.find((r: any) => r.id === s.roomId)?.name || "-";
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${s.day}</td><td>${s.time}</td><td>${teacherName}</td><td>${className}</td><td>${roomName}</td><td>${s.lessonName || ""}</td>
          <td>${currentUser.role === "teacher" ? `<button class="btnOpenLesson" data-id="${s.id}" aria-label="Upravljanje časom">Upravljaj</button>` : "-"}</td>
        `;
        tbody.appendChild(tr);
      });
      tbody.querySelectorAll(".btnOpenLesson").forEach((btn) => {
        btn.addEventListener("click", () => openLessonModal(btn.getAttribute("data-id")!));
      });
    }

    // ---- Lesson Modal ----
    function openLessonModal(scheduleId: string) {
      let schedules = loadData(STORAGE_SCHEDULES);
      const users = loadData(STORAGE_USERS);
      let attendance = loadData(STORAGE_ATTENDANCE);
      let grades = loadData(STORAGE_GRADES);

      const schedule = schedules.find((s: any) => s.id === scheduleId);
      if (!schedule) return;
      const classId = schedule.classId;
      const studentsInClass = users.filter((u: any) => u.role === "student" && u.class === classId);

      modalTitle.textContent = `Upravljanje časom: ${schedule.lessonName || "Nepoznato"}`;
      modalDesc.innerHTML = `
        <p><strong>Dan:</strong> ${schedule.day} <strong>Vrijeme:</strong> ${schedule.time}</p>
        <p><strong>Razred:</strong> ${classId}</p>
        <form id="lessonForm">
          <label for="lessonNameInput">Naziv lekcije</label>
          <input type="text" id="lessonNameInput" value="${schedule.lessonName || ""}" required />
          <h4>Upravljanje učenicima</h4>
          <table aria-label="Tablica prisutnosti i ocjena">
            <thead><tr><th>Ime učenika</th><th>Prisutan</th><th>Ocjena</th><th>Opomena</th><th>Ispitivanje</th></tr></thead>
            <tbody id="studentsLessonBody"></tbody>
          </table>
          <button type="submit" class="primary" style="margin-top:12px;">Spremi promjene</button>
        </form>
      `;
      const tbody = modalDesc.querySelector("#studentsLessonBody")!;
      tbody.innerHTML = "";
      studentsInClass.forEach((student: any) => {
        const att = attendance.find((a: any) => a.scheduleId === scheduleId && a.studentId === student.id);
        const grd = grades.filter((g: any) => g.scheduleId === scheduleId && g.studentId === student.id);
        const lastGrade = grd.length > 0 ? grd[grd.length - 1].grade : "";
        const lastWarning = att && att.warning ? att.warning : "";
        const lastTested = att && att.tested ? att.tested : false;
        const present = att ? att.status === "present" : true;
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${student.name}</td>
          <td><input type="checkbox" class="presentCheckbox" data-student="${student.id}" ${present ? "checked" : ""} aria-label="Prisutan"/></td>
          <td><input type="number" min="1" max="5" step="0.5" class="gradeInput" data-student="${student.id}" value="${lastGrade}"/></td>
          <td><input type="text" class="warningInput" data-student="${student.id}" value="${lastWarning}" placeholder="Npr. posjećen opomenu"/></td>
          <td><input type="checkbox" class="testedCheckbox" data-student="${student.id}" ${lastTested ? "checked" : ""} aria-label="Ispitivanje"/></td>
        `;
        tbody.appendChild(tr);
      });
      showModal();

      const form = modalDesc.querySelector("#lessonForm") as HTMLFormElement;
      form.addEventListener("submit", (e: Event) => {
        e.preventDefault();
        const newLessonName = (form.querySelector("#lessonNameInput") as HTMLInputElement).value.trim();
        if (!newLessonName) { alert("Unesite naziv lekcije."); return; }
        schedule.lessonName = newLessonName;
        schedules = schedules.map((s: any) => (s.id === schedule.id ? schedule : s));
        saveDataSync(STORAGE_SCHEDULES, schedules);

        studentsInClass.forEach((student: any) => {
          const presentEl = form.querySelector(`.presentCheckbox[data-student="${student.id}"]`) as HTMLInputElement;
          const gradeEl = form.querySelector(`.gradeInput[data-student="${student.id}"]`) as HTMLInputElement;
          const warningEl = form.querySelector(`.warningInput[data-student="${student.id}"]`) as HTMLInputElement;
          const testedEl = form.querySelector(`.testedCheckbox[data-student="${student.id}"]`) as HTMLInputElement;
          let att = attendance.find((a: any) => a.scheduleId === schedule.id && a.studentId === student.id);
          if (!att) {
            att = { id: createId("att"), scheduleId: schedule.id, studentId: student.id };
            attendance.push(att);
          }
          att.status = presentEl.checked ? "present" : "absent";
          att.warning = warningEl.value.trim();
          att.tested = testedEl.checked;
          if (gradeEl.value) {
            grades.push({ id: createId("grade"), studentId: student.id, scheduleId: schedule.id, grade: parseFloat(gradeEl.value), date: new Date().toISOString(), finalized: false, improved: false });
          }
        });
        saveDataSync(STORAGE_ATTENDANCE, attendance);
        saveDataSync(STORAGE_GRADES, grades);
        alert("Podaci časova su spremljeni.");
        hideModal();
        renderMySchedule();
      });
    }

    // ---- TEACHER: My Classes ----
    function renderMyClasses() {
      const users = loadData(STORAGE_USERS);
      const teacherClasses = currentUser.classes || [];
      if (teacherClasses.length === 0) { mainContent.innerHTML = "<h3>Ne predajete nijedan razred</h3>"; return; }
      mainContent.innerHTML = "<h3>Učenici vaših razreda</h3>";
      teacherClasses.forEach((classId: string) => {
        mainContent.innerHTML += `<h4>Razred: ${classId}</h4>`;
        const students = users.filter((u: any) => u.role === "student" && u.class === classId);
        if (students.length === 0) { mainContent.innerHTML += "<p>Nema učenika u ovom razredu.</p>"; } else {
          const table = document.createElement("table");
          table.setAttribute("aria-label", `Učenici razreda ${classId}`);
          table.innerHTML = "<thead><tr><th>Ime i prezime</th><th>Korisničko ime</th></tr></thead>";
          const tbody = document.createElement("tbody");
          students.forEach((s: any) => {
            const tr = document.createElement("tr");
            tr.innerHTML = `<td>${s.name}</td><td>${s.username}</td>`;
            tbody.appendChild(tr);
          });
          table.appendChild(tbody);
          mainContent.appendChild(table);
        }
      });
    }

    // ---- TEACHER: Grades & Attendance ----
    function renderGradesAttendance() {
      const users = loadData(STORAGE_USERS);
      const grades = loadData(STORAGE_GRADES);
      const attendance = loadData(STORAGE_ATTENDANCE);
      const teacherClasses = currentUser.classes || [];
      if (teacherClasses.length === 0) { mainContent.innerHTML = "<h3>Ne predajete nijedan razred</h3>"; return; }
      mainContent.innerHTML = "<h3>Ocjene i izostanci učenika</h3>";
      teacherClasses.forEach((classId: string) => {
        mainContent.innerHTML += `<h4>Razred: ${classId}</h4>`;
        const students = users.filter((u: any) => u.role === "student" && u.class === classId);
        if (students.length === 0) { mainContent.innerHTML += "<p>Nema učenika u ovom razredu.</p>"; return; }
        const table = document.createElement("table");
        table.setAttribute("aria-label", `Ocjene i izostanci razreda ${classId}`);
        table.innerHTML = "<thead><tr><th>Ime</th><th>Korisničko ime</th><th>Prosječna ocjena</th><th>Izostanci</th></tr></thead>";
        const tbody = document.createElement("tbody");
        students.forEach((s: any) => {
          const sg = grades.filter((g: any) => g.studentId === s.id);
          let avg = "-";
          if (sg.length > 0) { const sum = sg.reduce((a: number, g: any) => a + g.grade, 0); avg = (sum / sg.length).toFixed(2); }
          const abs = attendance.filter((a: any) => a.studentId === s.id && a.status === "absent").length;
          const tr = document.createElement("tr");
          tr.innerHTML = `<td>${s.name}</td><td>${s.username}</td><td>${avg}</td><td>${abs}</td>`;
          tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        mainContent.appendChild(table);
      });
    }

    // ---- TEACHER: Teacher Tracking ----
    function renderTeacherTracking() {
      const users = loadData(STORAGE_USERS);
      const schedules = loadData(STORAGE_SCHEDULES);
      const rooms = loadData(STORAGE_ROOMS);
      mainContent.innerHTML = "<h3>Praćenje učitelja</h3>";
      const teachers = users.filter((u: any) => u.role === "teacher");
      if (teachers.length === 0) { mainContent.innerHTML += "<p>Nema registriranih učitelja.</p>"; return; }
      const now = new Date();
      const dayNames = ["Nedjelja", "Ponedjeljak", "Utorak", "Srijeda", "Četvrtak", "Petak", "Subota"];
      const currentDay = dayNames[now.getDay()] || "";
      const currentTime = now.getHours() + ":" + String(now.getMinutes()).padStart(2, "0");

      function parseTime(t: string) { const [h, m] = t.split(":").map((x: string) => parseInt(x)); return h * 60 + m; }
      function timeInRange(current: string, start: string, end: string) { return parseTime(current) >= parseTime(start) && parseTime(current) <= parseTime(end); }

      const ul = document.createElement("ul");
      ul.style.listStyle = "none";
      ul.style.padding = "0";
      teachers.forEach((teacher: any) => {
        const teacherSchedule = schedules.filter((s: any) => s.teacher === teacher.id && s.day === currentDay);
        let currentRoom = "-";
        for (const sch of teacherSchedule) {
          const parts = sch.time.split(" - ");
          if (parts.length === 2 && timeInRange(currentTime, parts[0].trim(), parts[1].trim())) {
            const room = rooms.find((r: any) => r.id === sch.roomId);
            currentRoom = room ? room.name : "-";
            break;
          }
        }
        const li = document.createElement("li");
        li.style.padding = "8px 0";
        li.innerHTML = `<strong>${teacher.name}</strong>: trenutno u učionici <em>${currentRoom}</em>`;
        ul.appendChild(li);
      });
      mainContent.appendChild(ul);
    }

    // ---- STUDENT: My Grades ----
    function renderMyGrades() {
      const grades = loadData(STORAGE_GRADES);
      const schedules = loadData(STORAGE_SCHEDULES);
      if (!currentUser.class) { mainContent.innerHTML = "<h3>Niste dodijeljeni razredu.</h3>"; return; }
      const myGrades = grades.filter((g: any) => g.studentId === currentUser.id);
      if (myGrades.length === 0) { mainContent.innerHTML = "<h3>Nemate unesene ocjene.</h3>"; return; }
      mainContent.innerHTML = "<h3>Moje ocjene</h3>";
      const grouped: Record<string, any[]> = {};
      myGrades.forEach((g: any) => {
        const lessonName = schedules.find((s: any) => s.id === g.scheduleId)?.lessonName || "Nepoznata lekcija";
        if (!grouped[lessonName]) grouped[lessonName] = [];
        grouped[lessonName].push(g);
      });
      for (const lesson in grouped) {
        mainContent.innerHTML += `<h4>${lesson}</h4>`;
        const ul = document.createElement("ul");
        ul.style.listStyle = "none";
        ul.style.padding = "0";
        grouped[lesson].forEach((g: any) => {
          const li = document.createElement("li");
          li.textContent = `${g.grade} ${g.finalized ? "(Zaključena)" : ""} ${g.improved ? "(Popravljena)" : ""} - ${new Date(g.date).toLocaleDateString()}`;
          ul.appendChild(li);
        });
        mainContent.appendChild(ul);
      }
    }

    // ---- STUDENT: My Attendance ----
    function renderMyAttendance() {
      const attendance = loadData(STORAGE_ATTENDANCE);
      const schedules = loadData(STORAGE_SCHEDULES);
      const myAttendance = attendance.filter((a: any) => a.studentId === currentUser.id);
      if (myAttendance.length === 0) { mainContent.innerHTML = "<h3>Nemate evidentirane izostanke.</h3>"; return; }
      mainContent.innerHTML = "<h3>Moji izostanci</h3>";
      const table = document.createElement("table");
      table.setAttribute("aria-label", "Lista mojih izostanaka");
      table.innerHTML = `<thead><tr><th>Dan</th><th>Vrijeme</th><th>Razlog</th><th>Status</th></tr></thead>`;
      const tbody = document.createElement("tbody");
      myAttendance.forEach((a: any) => {
        if (a.status === "absent") {
          const schedule = schedules.find((s: any) => s.id === a.scheduleId) || {} as any;
          const tr = document.createElement("tr");
          tr.innerHTML = `<td>${schedule.day || "-"}</td><td>${schedule.time || "-"}</td><td>${a.warning || "-"}</td><td>${a.status}</td>`;
          tbody.appendChild(tr);
        }
      });
      table.appendChild(tbody);
      mainContent.appendChild(table);
    }

    // ---- Modal ----
    function showModal() { modalOverlay.style.display = "flex"; modalOverlay.focus(); }
    function hideModal() { modalOverlay.style.display = "none"; modalTitle.textContent = ""; modalDesc.innerHTML = ""; }
    modalCloseBtn.addEventListener("click", hideModal);
    modalOverlay.addEventListener("click", (e: Event) => { if (e.target === modalOverlay) hideModal(); });
    window.addEventListener("keydown", (e: KeyboardEvent) => { if (e.key === "Escape" && modalOverlay.style.display === "flex") hideModal(); });

    // ---- Initialize ----
    initDemoData();
  }, []);

  return (
    <div ref={containerRef}>
      <header style={{
        background: "#1e293b", padding: "16px 24px", textAlign: "center",
        position: "sticky", top: 0, zIndex: 1000, boxShadow: "0 2px 6px rgba(0,0,0,0.5)"
      }}>
        <h1 style={{
          fontSize: "1.8rem", fontWeight: 700, margin: "0 0 0 0",
          background: "linear-gradient(135deg, #667eea, #764ba2)",
          WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent"
        }}>Školska Aplikacija</h1>
      </header>

      <section id="authSection" aria-label="Prijava i registracija" style={{
        maxWidth: 420, margin: "48px auto", background: "#2d3748", borderRadius: 16,
        padding: "32px 24px", boxShadow: "0 0 25px rgba(102,126,234,0.4)", animation: "fadeIn 0.8s ease forwards"
      }}>
        <div className="tabs" role="tablist" style={{ display: "flex", justifyContent: "center", marginBottom: 24 }}>
          <div className="tab active" role="tab" id="loginTab" aria-selected="true" tabIndex={0}
            style={{ cursor: "pointer", padding: "12px 24px", background: "#667eea", borderRadius: "8px 8px 0 0",
              margin: "0 4px", color: "white", fontWeight: 700, boxShadow: "0 4px 15px rgba(102,126,234,0.5)" }}>
            Prijava
          </div>
          <div className="tab" role="tab" id="registerTab" aria-selected="false" tabIndex={-1}
            style={{ cursor: "pointer", padding: "12px 24px", background: "#334155", borderRadius: "8px 8px 0 0",
              margin: "0 4px", color: "#a0aec0", fontWeight: 700 }}>
            Registracija
          </div>
        </div>
        <div id="loginPanel" role="tabpanel" aria-labelledby="loginTab">
          <form id="loginForm" autoComplete="username" style={{ display: "flex", flexDirection: "column" }}>
            <label htmlFor="loginUsername" style={{ fontWeight: 600, marginBottom: 6 }}>Korisničko ime</label>
            <input type="text" id="loginUsername" name="username" autoComplete="username" required aria-required="true"
              style={{ padding: "10px 12px", borderRadius: 8, border: "none", marginBottom: 16, width: "100%", background: "#334155", color: "white", fontSize: "1rem" }} />
            <label htmlFor="loginPassword" style={{ fontWeight: 600, marginBottom: 6 }}>Lozinka</label>
            <input type="password" id="loginPassword" name="password" autoComplete="current-password" required aria-required="true"
              style={{ padding: "10px 12px", borderRadius: 8, border: "none", marginBottom: 16, width: "100%", background: "#334155", color: "white", fontSize: "1rem" }} />
            <button type="submit" style={{
              cursor: "pointer", border: "none", borderRadius: 8, padding: "10px 16px", fontWeight: 600,
              background: "linear-gradient(135deg, #667eea, #764ba2)", color: "white", boxShadow: "0 4px 15px rgba(118,75,162,0.4)"
            }}>Prijavi se</button>
          </form>
        </div>
        <div id="registerPanel" role="tabpanel" aria-labelledby="registerTab" hidden>
          <form id="registerForm" autoComplete="off" style={{ display: "flex", flexDirection: "column" }}>
            <label htmlFor="registerName" style={{ fontWeight: 600, marginBottom: 6 }}>Ime i prezime</label>
            <input type="text" id="registerName" name="name" required aria-required="true"
              style={{ padding: "10px 12px", borderRadius: 8, border: "none", marginBottom: 16, width: "100%", background: "#334155", color: "white", fontSize: "1rem" }} />
            <label htmlFor="registerRole" style={{ fontWeight: 600, marginBottom: 6 }}>Uloga</label>
            <select id="registerRole" name="role" required aria-required="true"
              style={{ padding: "10px 12px", borderRadius: 8, border: "none", marginBottom: 16, width: "100%", background: "#334155", color: "white", fontSize: "1rem" }}>
              <option value="">Odaberite ulogu</option>
              <option value="admin">Admin</option>
              <option value="teacher">Učitelj</option>
              <option value="student">Učenik</option>
            </select>
            <label htmlFor="registerUsername" style={{ fontWeight: 600, marginBottom: 6 }}>Korisničko ime</label>
            <input type="text" id="registerUsername" name="username" required aria-required="true"
              style={{ padding: "10px 12px", borderRadius: 8, border: "none", marginBottom: 16, width: "100%", background: "#334155", color: "white", fontSize: "1rem" }} />
            <label htmlFor="registerPassword" style={{ fontWeight: 600, marginBottom: 6 }}>Lozinka</label>
            <input type="password" id="registerPassword" name="password" required aria-required="true"
              style={{ padding: "10px 12px", borderRadius: 8, border: "none", marginBottom: 16, width: "100%", background: "#334155", color: "white", fontSize: "1rem" }} />
            <button type="submit" style={{
              cursor: "pointer", border: "none", borderRadius: 8, padding: "10px 16px", fontWeight: 600,
              background: "linear-gradient(135deg, #667eea, #764ba2)", color: "white", boxShadow: "0 4px 15px rgba(118,75,162,0.4)"
            }}>Registriraj se</button>
          </form>
        </div>
        <div id="authMessage" role="alert" aria-live="assertive" style={{ marginTop: 16, textAlign: "center" }}></div>
      </section>

      <section id="dashboard" aria-label="Glavna kontrolna ploča" style={{
        display: "none", flexDirection: "column", minHeight: "calc(100vh - 68px)", paddingBottom: 48, animation: "fadeIn 0.8s ease forwards"
      }}>
        <div id="dashboardHeader" role="banner" aria-live="polite" style={{
          background: "#1e293b", padding: "0 24px", display: "flex", justifyContent: "space-between",
          alignItems: "center", boxShadow: "0 2px 8px rgba(0,0,0,0.4)"
        }}>
          <h2 style={{ margin: "12px 0", fontWeight: 700, color: "#e0e7ff" }}>
            Dobrodošli, <span id="userNameDisplay"></span>{" "}
            <span id="userRoleBadge" style={{
              display: "inline-block", backgroundColor: "#667eea", color: "white", padding: "4px 10px",
              fontSize: "0.75rem", borderRadius: 12, fontWeight: 700
            }}></span>
          </h2>
          <button id="logoutBtn" aria-label="Odjavi se" style={{
            background: "transparent", color: "#a0aec0", border: "2px solid #667eea",
            padding: "8px 20px", fontWeight: 600, borderRadius: 12, cursor: "pointer"
          }}>
            Odjava <span className="material-icons" aria-hidden="true">logout</span>
          </button>
        </div>
        <div id="dashboardMain" style={{ display: "flex", marginTop: 16, flex: "1 1 auto", overflow: "hidden", minHeight: 500 }}>
          <nav id="sideMenu" role="navigation" aria-label="Glavni izbornik" style={{
            background: "#2d3748", width: 260, minWidth: 260, padding: "32px 16px",
            display: "flex", flexDirection: "column", gap: 18, flexShrink: 0
          }}></nav>
          <main id="mainContent" tabIndex={0} aria-live="polite" aria-atomic="true" style={{
            flex: 1, background: "#1e293b", marginLeft: 20, borderRadius: 16, padding: 24, overflowY: "auto"
          }}></main>
        </div>
      </section>

      <div id="modalOverlay" role="dialog" aria-modal="true" aria-labelledby="modalTitle" aria-describedby="modalDesc" tabIndex={-1}
        style={{
          position: "fixed", top: 0, left: 0, right: 0, bottom: 0, background: "rgba(0,0,0,0.65)",
          display: "none", alignItems: "center", justifyContent: "center", padding: 16, zIndex: 2000
        }}>
        <div id="modal" style={{
          background: "#273754", borderRadius: 16, maxWidth: 600, width: "100%", padding: 24,
          color: "#e2e8f0", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 8px 40px rgba(102,126,234,0.7)"
        }}>
          <div id="modalHeader" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
            <h3 id="modalTitle" style={{ margin: 0 }}></h3>
            <button id="modalClose" aria-label="Zatvori modal" style={{
              cursor: "pointer", fontSize: "1.5rem", color: "#a0aec0", background: "none", border: "none"
            }}>
              <span className="material-icons" aria-hidden="true">close</span>
            </button>
          </div>
          <div id="modalDesc"></div>
        </div>
      </div>
    </div>
  );
}
