import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  getDoc,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDEXc3HNgvIylJE7J2kmwvj6G7SMQchos4",
  authDomain: "skola-44124.firebaseapp.com",
  projectId: "skola-44124",
  storageBucket: "skola-44124.firebasestorage.app",
  messagingSenderId: "969918362630",
  appId: "1:969918362630:web:5e8ee798684e7f2eff3f87",
  measurementId: "G-K4L0FD0NT0",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db, collection, doc, getDocs, setDoc, deleteDoc, getDoc };
export default db;
